const envList = [{"envId":"zcheny-0gte73kn097962b6","alias":"zcheny"}]
const isMac = false
module.exports = {
    envList,
    isMac
}
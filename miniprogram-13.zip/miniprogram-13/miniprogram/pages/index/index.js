// index.js
// const app = getApp()
const { envList } = require('../../envList.js');

Page({
 navigate(){
    wx.redirectTo({
        url: 'pages/bluetooth/index'
      })
 }
});
